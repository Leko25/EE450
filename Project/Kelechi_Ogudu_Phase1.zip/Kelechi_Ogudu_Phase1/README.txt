Name: Kelechi Ogudu
USC_ID: 5413285132


Compilation step:
----------------
For Phase 1 I have utilized fork() system call to combine DepartmentA, DepartmentB,
and DepartmentC into a single client Department.c. To run the program simply
compile and run Admissions.c and then compile and run Department.c.

References:
-----------
The initial setup for the TCP for both Department.c and Admissions.c is
obtained from "Beej's Guide to Network Programming".
